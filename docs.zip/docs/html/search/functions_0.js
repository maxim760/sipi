var searchData=
[
  ['addcertificate_0',['addCertificate',['../classcom_1_1example_1_1pizzeria_1_1controller_1_1_certificate_controller.html#a2b0cb1b03b5c7b8ff6dc4c62566b19c0',1,'com::example::pizzeria::controller::CertificateController']]]
];

var searchData=
[
  ['getaddcertpage_0',['getAddCertPage',['../classcom_1_1example_1_1pizzeria_1_1controller_1_1_certificate_controller.html#af40b7ccdda0bd3b931920344a81260b1',1,'com::example::pizzeria::controller::CertificateController']]],
  ['getcertpage_1',['getCertPage',['../classcom_1_1example_1_1pizzeria_1_1controller_1_1_certificate_controller.html#a3c193b1d52d5c170c719f74ae8a4fd3f',1,'com::example::pizzeria::controller::CertificateController']]],
  ['getcurierpage_2',['getCurierPage',['../classcom_1_1example_1_1pizzeria_1_1controller_1_1_curier_controller.html#aac8ddd28434e7d823642a10704e0ed0c',1,'com::example::pizzeria::controller::CurierController']]]
];

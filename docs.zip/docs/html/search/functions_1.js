var searchData=
[
  ['create_0',['create',['../classcom_1_1example_1_1pizzeria_1_1service_1_1_certificate_service.html#ad1077e66d7d2e907fe44043327a70b3d',1,'com::example::pizzeria::service::CertificateService']]]
];

var searchData=
[
  ['filtergoodsdto_0',['FilterGoodsDTO',['../classcom_1_1example_1_1pizzeria_1_1_d_t_o_1_1_filter_goods_d_t_o.html',1,'com::example::pizzeria::DTO']]]
];

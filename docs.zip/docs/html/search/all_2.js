var searchData=
[
  ['editcurierinfo_0',['editCurierInfo',['../classcom_1_1example_1_1pizzeria_1_1controller_1_1_curier_controller.html#aab507f6201419abcf9390714f45e1ce0',1,'com::example::pizzeria::controller::CurierController']]]
];

var searchData=
[
  ['updateaddcertpage_0',['updateAddCertPage',['../classcom_1_1example_1_1pizzeria_1_1controller_1_1_certificate_controller.html#a5146388a54592dd157adf3282d38bda6',1,'com::example::pizzeria::controller::CertificateController']]]
];
